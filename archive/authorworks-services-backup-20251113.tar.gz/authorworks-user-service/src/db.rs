use anyhow::Result;
use sqlx::{PgPool, Row};
use uuid::Uuid;

use crate::models::{UpdateProfileRequest, User};

/// Create a new user in the database
pub async fn create_user(
    pool: &PgPool,
    email: &str,
    username: &str,
    password_hash: &str,
    display_name: Option<&str>,
) -> Result<User> {
    let user = sqlx::query_as::<_, User>(
        r#"
        INSERT INTO users (email, username, password_hash, display_name, subscription_tier, subscription_status, profile_data)
        VALUES ($1, $2, $3, $4, 'free', 'active', '{}')
        RETURNING *
        "#,
    )
    .bind(email)
    .bind(username)
    .bind(password_hash)
    .bind(display_name)
    .fetch_one(pool)
    .await?;

    Ok(user)
}

/// Find a user by email
pub async fn find_user_by_email(pool: &PgPool, email: &str) -> Result<Option<User>> {
    let user = sqlx::query_as::<_, User>("SELECT * FROM users WHERE email = $1")
        .bind(email)
        .fetch_optional(pool)
        .await?;

    Ok(user)
}

/// Find a user by ID
pub async fn find_user_by_id(pool: &PgPool, id: Uuid) -> Result<Option<User>> {
    let user = sqlx::query_as::<_, User>("SELECT * FROM users WHERE id = $1")
        .bind(id)
        .fetch_optional(pool)
        .await?;

    Ok(user)
}

/// Find a user by username
pub async fn find_user_by_username(pool: &PgPool, username: &str) -> Result<Option<User>> {
    let user = sqlx::query_as::<_, User>("SELECT * FROM users WHERE username = $1")
        .bind(username)
        .fetch_optional(pool)
        .await?;

    Ok(user)
}

/// Update user's last login timestamp
pub async fn update_last_login(pool: &PgPool, user_id: Uuid) -> Result<()> {
    sqlx::query("UPDATE users SET last_login = NOW() WHERE id = $1")
        .bind(user_id)
        .execute(pool)
        .await?;

    Ok(())
}

/// Update user profile
pub async fn update_user_profile(
    pool: &PgPool,
    user_id: Uuid,
    request: &UpdateProfileRequest,
) -> Result<User> {
    let user = sqlx::query_as::<_, User>(
        r#"
        UPDATE users
        SET display_name = COALESCE($2, display_name),
            profile_data = COALESCE($3, profile_data),
            updated_at = NOW()
        WHERE id = $1
        RETURNING *
        "#,
    )
    .bind(user_id)
    .bind(&request.display_name)
    .bind(&request.profile_data)
    .fetch_one(pool)
    .await?;

    Ok(user)
}

/// Get all users (admin only)
pub async fn list_users(pool: &PgPool, limit: i64, offset: i64) -> Result<Vec<User>> {
    let users = sqlx::query_as::<_, User>(
        "SELECT * FROM users ORDER BY created_at DESC LIMIT $1 OFFSET $2",
    )
    .bind(limit)
    .bind(offset)
    .fetch_all(pool)
    .await?;

    Ok(users)
}

/// Get user's book count
pub async fn get_user_book_count(pool: &PgPool, user_id: Uuid) -> Result<i64> {
    let count = sqlx::query("SELECT COUNT(*) as count FROM books WHERE user_id = $1")
        .bind(user_id)
        .fetch_one(pool)
        .await?
        .get("count");

    Ok(count)
}

/// Check if email exists
pub async fn email_exists(pool: &PgPool, email: &str) -> Result<bool> {
    let exists = sqlx::query("SELECT EXISTS(SELECT 1 FROM users WHERE email = $1)")
        .bind(email)
        .fetch_one(pool)
        .await?
        .get(0);

    Ok(exists)
}

/// Check if username exists
pub async fn username_exists(pool: &PgPool, username: &str) -> Result<bool> {
    let exists = sqlx::query("SELECT EXISTS(SELECT 1 FROM users WHERE username = $1)")
        .bind(username)
        .fetch_one(pool)
        .await?
        .get(0);

    Ok(exists)
}
