mod auth;
mod db;
mod handlers;
mod models;

use axum::{
    http::{header, HeaderValue, Method},
    routing::{get, patch, post},
    Router,
};
use handlers::AppState;
use sqlx::postgres::PgPoolOptions;
use std::net::SocketAddr;
use tower_http::cors::{AllowHeaders, AllowMethods, AllowOrigin, CorsLayer};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

#[tokio::main]
async fn main() {
    // Initialize tracing
    tracing_subscriber::registry()
        .with(
            tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_| {
                "authorworks_user_service=debug,tower_http=debug,sqlx=info".into()
            }),
        )
        .with(tracing_subscriber::fmt::layer())
        .init();

    tracing::info!("Starting AuthorWorks User Service v1.0.0");

    // Get configuration from environment
    let database_url = std::env::var("DATABASE_URL")
        .expect("DATABASE_URL must be set");

    let jwt_secret = std::env::var("JWT_SECRET")
        .unwrap_or_else(|_| {
            tracing::warn!("JWT_SECRET not set, using default (INSECURE for production!)");
            "default_jwt_secret_change_in_production".to_string()
        });

    let host = std::env::var("HOST").unwrap_or_else(|_| "0.0.0.0".to_string());
    let port: u16 = std::env::var("SERVICE_PORT")
        .or_else(|_| std::env::var("PORT"))
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(3001);

    // Create database connection pool
    tracing::info!("Connecting to database...");
    let pool = PgPoolOptions::new()
        .max_connections(20)
        .connect(&database_url)
        .await
        .expect("Failed to connect to database");

    tracing::info!("Database connection established");

    // Create application state
    let state = AppState {
        pool: pool.clone(),
        jwt_secret,
    };

    // Configure CORS
    let cors = match std::env::var("ALLOWED_ORIGINS") {
        Ok(val) if !val.trim().is_empty() => {
            let origins: Vec<HeaderValue> = val
                .split(',')
                .filter_map(|o| HeaderValue::from_str(o.trim()).ok())
                .collect();
            tracing::info!("CORS enabled for origins: {}", val);
            CorsLayer::new()
                .allow_origin(AllowOrigin::list(origins))
                .allow_methods(vec![
                    Method::GET,
                    Method::POST,
                    Method::PATCH,
                    Method::PUT,
                    Method::DELETE,
                    Method::OPTIONS,
                ])
                .allow_headers(vec![
                    header::AUTHORIZATION,
                    header::CONTENT_TYPE,
                    header::ACCEPT,
                    header::HeaderName::from_static("remote-user"),
                ])
                .allow_credentials(true)
        }
        _ => {
            tracing::warn!("CORS set to permissive mode");
            CorsLayer::permissive()
        }
    };

    // Build application router
    let app = Router::new()
        .route("/", get(handlers::root))
        .route("/health", get(handlers::health_check))
        // Auth routes
        .route("/api/v1/auth/register", post(handlers::register))
        .route("/api/v1/auth/login", post(handlers::login))
        .route("/api/v1/auth/me", get(handlers::get_current_user))
        // User routes
        .route("/api/v1/users", get(handlers::list_users))
        .route("/api/v1/users/:id", get(handlers::get_user))
        .route("/api/v1/users/:id", patch(handlers::update_profile))
        .route("/api/v1/users/:id/stats", get(handlers::get_user_stats))
        .layer(cors)
        .with_state(state);

    // Start server
    let addr: SocketAddr = format!("{}:{}", host, port)
        .parse()
        .expect("Invalid HOST/PORT");

    tracing::info!("AuthorWorks User Service listening on {}", addr);
    tracing::info!("Available endpoints:");
    tracing::info!("  GET  /health - Health check");
    tracing::info!("  POST /api/v1/auth/register - User registration");
    tracing::info!("  POST /api/v1/auth/login - User login");
    tracing::info!("  GET  /api/v1/auth/me - Get current user");
    tracing::info!("  GET  /api/v1/users - List users");
    tracing::info!("  GET  /api/v1/users/:id - Get user by ID");
    tracing::info!("  PATCH /api/v1/users/:id - Update user profile");
    tracing::info!("  GET  /api/v1/users/:id/stats - Get user statistics");

    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
